DROP_IT v4.2 sequential measurements

Program SHA-256: `e0e93a0e5a3130f0dd1c92f655dc6b5618a439c1a1f7a888f248a828973cea8f`

Parent SHA-256: `4f6977187b54ef6131f2041abee4a93440bc5507a23f5c9f1827e520091cd087`

Status: COMPLETED; valid primary turns: 64/64.

Primary exposed thread IDs: ["01a07d62-e0c3-7e02-b2f8-80bbf2f9a5dc"].

Exposed model IDs: []; null count: 64.

| Marker | Sequential matched 16 | Fresh-thread baseline 16 | Sequential full 64 |
|---|---:|---:|---:|
| C_n_literal | 0/16 = 0.000000 | 0/16 = 0.000000 | 0/64 = 0.000000 |
| W_n | 0/16 = 0.000000 | 0/16 = 0.000000 | 0/64 = 0.000000 |
| H_n | 0/16 = 0.000000 | 0/16 = 0.000000 | 0/64 = 0.000000 |
| A_n | 0/16 = 0.000000 | 0/16 = 0.000000 | 0/64 = 0.000000 |
| U_n | 0/16 = 0.000000 | 3/16 = 0.187500 | 0/64 = 0.000000 |
| strict_any | 0/16 = 0.000000 | 0/16 = 0.000000 | 0/64 = 0.000000 |
| broad_any | 0/16 = 0.000000 | 0/16 = 0.000000 | 0/64 = 0.000000 |

| Current condition | p11 | p01 | Lambda |
|---|---:|---:|---:|
| pooled | 0/0 = NULL | 0/63 = 0.000000 | NULL |
| A | 0/0 = NULL | 0/16 = 0.000000 | NULL |
| B | 0/0 = NULL | 0/16 = 0.000000 | NULL |
| C | 0/0 = NULL | 0/15 = 0.000000 | NULL |
| D | 0/0 = NULL | 0/16 = 0.000000 | NULL |
| first half | 0/0 = NULL | 0/31 = 0.000000 | NULL |
| second half | 0/0 = NULL | 0/32 = 0.000000 | NULL |

| Second-order state | Next C=1 |
|---|---:|
| q00 | 0/62 = 0.000000 |
| q01 | 0/0 = NULL |
| q10 | 0/0 = NULL |
| q11 | 0/0 = NULL |

Separately exposed assistant items: 64.

Geometry answers: {"expected": 32, "recognized": 32, "correct": 32}.

Exact current wrapper matches: 0 across 462 captured event payloads.

Receipts: 678; distinct validated payloads: 432; chain/payload errors: 0/0.

Receipt head: `078efcac6ee33d8b5f9eec3fd001b1ec647247d73477076406b9a2316b8dd859`

Plan SHA-256: `197a0932b7ce97145be9499481ba877cb91e7e21c713b3b535e1b9eb672922e4`

Runtime SHA-256: `b896c1a248e2a524a8ced708ba408a2696b71ad30b7bd16d6467a013a7645c1a`

Codebook SHA-256: `dda4c65d2710b2fb33dc91af02ef3750c537261ac19162f3c14b6a547fea196a`
