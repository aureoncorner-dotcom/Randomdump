# Toroidal consolidated archive

Author: Anonymous. CC0 1.0.

Use the live working master for current work: https://docs.google.com/document/d/1NV7JsFuqJJVjFzYcqCAuC22y_rrjCSqqcZWZKobcGoU/edit?usp=drivesdk

This ZIP consolidates the supplied attachment bytes and readable snapshots of 17 related Drive source records. It is not an executable simulation package. Native Google Docs originals, their formatting, comments and version history remain in Drive; readable snapshots are not native backups. Linked general geometry and Hidden Quotient records remain separate project sources.

The source archive is https://drive.google.com/drive/folders/17P1St3hK26XlWkgSijHamP5bmeyO_weg

The prior geometry tab was verified unchanged. Sixteen loose Drive records were moved into the source archive; one already-filed receipt retained its original location. No source document was deleted.

New scientific status is not inferred from consolidation. The original L=3 pilot remains UNRESOLVED; its separate follow-up reports engineering PASS; physical Q2 remains NOT_RUN. Historical replay mismatch and truncated verifier remain open.

attachments/ preserves the uploaded inputs, including their historical naming and checklists. drive_sources/ contains readable connector extractions, whose hashes identify these snapshot bytes only. SHA256SUMS.txt covers every other member of this ZIP.
